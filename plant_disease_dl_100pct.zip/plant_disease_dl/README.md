# RobustLeaf-Net: Plant Disease Detection (100% implementation)

## Status: all modules built
| Module | Files |
|---|---|
| Data pipeline, augmentation, Background Randomization (SBR) | `data.py` |
| Baseline CNN, transfer learning, CBAM, mask-guided attention, hierarchical heads | `models.py` |
| Training and ablation runs | `train.py`, `run_ablation.sh` |
| Evaluation (accuracy, F1, confusion matrix, field gap, size, speed) | `evaluate.py` |
| Grad-CAM explainability | `gradcam.py` |
| Severity estimate | `severity.py` |
| Disease knowledge base (38 classes) | `disease_info.json` |
| PDF disease report | `report.py` |
| Web app | `app.py` |
| Field testing from the command line | `predict.py` |
| Paper results table | `make_results_table.py`, `PAPER_TEMPLATE.md`, `RESEARCH_PLAN.md` |

## Setup
Python 3.10-3.12.
```
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
```
Dataset: PlantVillage (Kaggle `abdallahalidev/plantvillage-dataset`), use the `color` folder.

## 1. Smoke test (no download, about 2 minutes)
```
python make_synthetic.py synthetic_data
python train.py --data_dir synthetic_data --run_name smoke --model transfer --cbam --sbr --attn_sup --hier --no_pretrained --epochs_head 1 --epochs_ft 1 --batch 8 --split_file runs/smoke_splits.json
```
Then test the app on that model (the fake classes are not in the knowledge base, so a generic entry is shown):
```
streamlit run app.py        # set "Splits file" to runs/smoke_splits.json in the sidebar
```

## 2. Train (use Google Colab GPU for the full dataset)
```
python train.py --data_dir PlantVillage/color --run_name A5_full --model transfer --cbam --sbr --attn_sup --hier
bash run_ablation.sh PlantVillage/color path/to/field_images     # all 6 variants
SEED=1 bash run_ablation.sh ...   and   SEED=2 bash run_ablation.sh ...   # 3 seeds for the paper
```
Laptop without GPU: add `--max_per_class 200 --batch 16 --epochs_head 3 --epochs_ft 3 --split_file runs/small_splits.json`.

## 3. Use the system
```
streamlit run app.py                                              # web app: upload photo -> diagnosis + Grad-CAM + PDF report
python predict.py --run_name A5_full --input field_photos/ --out_dir reports/   # batch field testing, PDFs + predictions.csv
python evaluate.py --run_name A5_full --data_dir PlantVillage/color --ood_dir PlantDoc/test --ood_map mapping.json
python make_results_table.py                                      # results_table.md / .csv for the paper
```
`mapping.json` example: `{"Tomato leaf late blight": "Tomato___Late_blight"}`

## Notes
* Verified here: the severity estimate, PDF report, knowledge base and results-table scripts were executed. The TensorFlow parts (training, Grad-CAM, app) were syntax-checked only, so run the smoke test first and report any traceback.
* Severity is a colour-based estimate of the affected leaf area, not a lab measurement.
* The report is advisory. Treatments are general guidance; always follow product labels and local advice.
* The app expects one leaf photo. It cannot tell that an image is not a leaf.

## 4. Build the paper (IEEE LaTeX) from your real results (or just run colab_run_all.ipynb on Colab)
Everything in `paper/main.tex` that depends on experiments is filled automatically; nothing is invented.
```
bash run_ablation.sh PlantVillage/color path/to/field_images          # SEED=42, then SEED=1, SEED=2
python make_paper_figures.py --data_dir PlantVillage/color --field_dir path/to/field_images
python fill_paper.py --field_images 480 --field_classes 12 --gpu "NVIDIA T4 (Colab)" --device "Intel Core i5 CPU"
```
Upload the `paper/` folder (main.tex, numbers.tex, results_rows.tex, figs/) to Overleaf and compile with pdfLaTeX.
Red text = still a placeholder. You must type the authors' affiliation, e-mails and acknowledgment yourself.
Write the interpretation of the results (which component helped and why) after you have seen the numbers.
