# Research Plan: Robust Plant Disease Recognition via Background Randomization and Mask-Guided Attention

*Working name of the method: **RobustLeaf-Net***

## 1. Problem and gap
Models reach 95-99% on PlantVillage, but accuracy drops sharply on real field images. A key reason is **shortcut learning**: PlantVillage images have clean, uniform backgrounds, so networks can use background and capture-condition cues instead of the lesion itself. Most published work only reports in-domain accuracy, so the field-generalisation problem is under-addressed.

## 2. Proposed algorithm (new contribution)
A lightweight MobileNetV2/EfficientNet-B0 transfer-learning model with three components:

1. **SBR - Saturation-based Background Randomization (augmentation).** A leaf mask is estimated from colour saturation (no manual annotation), and the background is replaced with random colour and noise during training. This removes the background shortcut.
2. **MGA - Mask-Guided Attention supervision.** A CBAM block sits on the backbone feature map. Its spatial attention map is trained, with an extra loss, to match the estimated leaf mask, so the network learns to *attend to the leaf* rather than the background.
3. **Hierarchical multi-task heads.** Crop and disease are predicted jointly. At inference, **crop-consistent decoding** only allows diseases that belong to the predicted crop.

Loss: `L = L_disease + 0.3 * L_crop + 0.2 * BCE(attn_map, leaf_mask)`

**Hypothesis:** the full model keeps in-domain accuracy (about equal to the baselines) while clearly shrinking the in-domain to field generalisation gap, with a small model suitable for mobile deployment.

## 3. Experiments (what the paper needs)
| Run | Description |
|---|---|
| A0 | Baseline CNN from scratch |
| A1 | MobileNetV2 transfer learning |
| A2 | A1 + CBAM |
| A3 | A2 + SBR |
| A4 | A3 + mask-guided attention |
| A5 | A4 + hierarchical heads (full model) |

* **In-domain:** PlantVillage test split (accuracy, macro-P/R/F1, confusion matrix).
* **Cross-domain (the key result):** train on PlantVillage, test on field images (e.g. PlantDoc, or your own photos) using the shared classes. Report the generalisation gap.
* **Efficiency:** parameters, model size (MB), latency per image.
* **Rigor:** 3 seeds (`SEED=42,1,2`), report mean +- std; ablation table; optional comparison with EfficientNet-B0 / ResNet50 / ViT baselines.
* **Explainability:** Grad-CAM before/after (part of the remaining 40%), plus an attention-vs-leaf-mask overlap score.

## 4. Paper outline
Abstract, Introduction (gap: lab-to-field), Related Work, Method (SBR, MGA, hierarchical decoding), Datasets and Setup, Results (in-domain, cross-domain, ablation, efficiency), Explainability, Limitations, Conclusion.

## 5. Honest caveats before submission
* CBAM, multi-task learning and background augmentation each exist in the literature. The novelty claim is the **specific combination**, especially leaf-mask-supervised attention without manual labels, evaluated on **cross-domain generalisation**. Do a proper literature search (Scopus / Google Scholar) before finalising the claim.
* The claim only holds if experiments show a real improvement in the cross-domain gap. If a component does not help, report it honestly in the ablation.
* The saturation-based mask is a heuristic; show a failure analysis (e.g. low-saturation leaves, white-background photos).

## 6. Possible venues
Computers and Electronics in Agriculture; Frontiers in Plant Science; Plants (MDPI); IEEE Access; Smart Agricultural Technology; or national/international conferences on AI in agriculture.
