# Paper skeleton: Robust Plant Disease Recognition via Background Randomization and Mask-Guided Attention

**Abstract (fill after results).** Problem (lab-to-field gap) -> method (SBR + mask-guided attention + hierarchical heads) -> key numbers (in-domain, field accuracy, gap) -> model size.

## 1 Introduction
Crop-loss motivation; deep-learning success on PlantVillage; shortcut learning on clean backgrounds; contributions (3 bullets: SBR, mask-guided attention without manual labels, cross-domain evaluation with ablation).

## 2 Related work
CNN/transfer learning for plant disease; attention modules (CBAM); background/augmentation strategies; domain generalisation; explainability (Grad-CAM). *(Do the literature search and cite 20-30 papers.)*

## 3 Method
3.1 Backbone and two-stage fine-tuning. 3.2 Saturation-based Background Randomization (Eq. for mask, blending). 3.3 Mask-Guided Attention loss. 3.4 Hierarchical heads and crop-consistent decoding. 3.5 Total loss `L = L_disease + 0.3 L_crop + 0.2 BCE(A, M)`.

## 4 Experiments
4.1 Datasets: PlantVillage (in-domain, 70/15/15 stratified), field set (cross-domain). 4.2 Implementation details (224x224, Adam, lr 1e-3 then 1e-5, batch 32, seeds 42/1/2). 4.3 Metrics.

## 5 Results
Table 1 (paste `results_table.md`): ablation A0-A5, mean ± std over 3 seeds.
Figure: confusion matrix (`runs/A5_full/confusion_matrix.png`). Figure: Grad-CAM A1 vs A5 on field images.
Discussion: which component reduces the field gap; hierarchical decoding gain; failure cases (low-saturation leaves, white backgrounds, multiple leaves).

## 6 Deployment
Streamlit app, PDF disease report, model size and latency.

## 7 Limitations and future work
Colour-based mask is heuristic; limited field data; severity is an estimate; extend to detection/segmentation.

## 8 Conclusion
